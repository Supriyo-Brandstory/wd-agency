========================================================================
ENTERPRISE BULK UPLOAD TEMPLATE - DUBAI WEB DEVELOPMENT AGENCY
========================================================================

How to use this package:
1. "sample-landing-page.html" is a fully responsive, long-form content template
   built for high-converting Dubai & UAE enterprise SEO landing pages.
2. Styling Features:
   - Dark luxury aesthetic (#060911 theme)
   - Zero external images (100% pure CSS keyframe animations & vector SVGs)
   - Strict typography enforcement (all fonts are 16px or larger for readability)
   - 4 Spaced-Out Technical Comparison & Deliverables Tables (responsive horizontal scroll)
   - Seamless embedding (no duplicate header or footer; works out-of-the-box with site layout)
   - Comprehensive technical deep dives and enterprise architectural sections
3. SEO & Head Parser Compatibility:
   - Automatically parses <title>
   - Automatically parses <meta name="description">
   - Automatically parses <link rel="canonical"> to form slug
   - Automatically encapsulates <script type="application/ld+json"> schema and fonts into SEO Script

You can modify text, add your own HTML files into this ZIP, and upload it via
the Admin Bulk Upload tool.
