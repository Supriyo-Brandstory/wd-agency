================================================================================
BULK CUSTOM PAGE UPLOAD - SAMPLE ZIP TEMPLATE GUIDE
================================================================================

This sample ZIP demonstrates the exact structure required for bulk page uploads:

PACKAGE STRUCTURE:
-----------------
your-package.zip/
  ├── sample-landing-page.html     (Your HTML page - one or multiple .html files)
  ├── images/                      (All image assets)
  │     └── clients/
  │           ├── logo-1.png
  │           ├── logo-2.png
  │           └── ...
  └── README-GUIDE.txt             (Optional notes/docs)

HOW THE SYSTEM PROCESSES YOUR FILES:
------------------------------------
1. <head> Tag Extraction:
   - <title>: Automatically extracted and saved to SEO metadata.
   - <meta name="description" content="...">: Saved to SEO description.
   - <link rel="canonical" href="...">: Automatically extracts the URL slug.
   - <script type="application/ld+json">: Parsed and added to Schema SEO.
   - <style>: Extracted into a dedicated CSS stylesheet (/uploads/css/slug.css).
   - Google Fonts links: Loaded dynamically on page render.

2. Image Folder Binding:
   - All files in the images/ folder are extracted to media storage.
   - Relative image references like:
       <img src="images/clients/logo-1.png" />
       <img src="./images/clients/logo-1.png" />
       url('images/clients/logo-1.png')
     are automatically rewritten to work seamlessly.

3. XML Sitemap Auto-Sync:
   - The page slug is instantly added to /sitemap.xml with priority 0.80 and current timestamp.
   - Editing the slug updates the sitemap automatically.
   - Deleting the page removes it from the sitemap and deletes its SEO record.

HOW TO ZIP YOUR FILES:
----------------------
Select your HTML file(s) and the images/ folder together, right-click, and choose
'Compress' (or 'Send to -> Compressed (zipped) folder'). Then upload the .zip file!
================================================================================